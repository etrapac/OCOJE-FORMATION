# OCOJE Formation

Prototype web bilingue français / kreyòl ayisyen de l'Organisation Communautaire pour l’Orientation des Jeunes et leur Engagement.

## Fonctions incluses
- Accueil institutionnel et catalogue de cours.
- Interface française et créole haïtien.
- Recherche et filtre par catégorie.
- Fiches de cours, modules et suivi de progression.
- Espace personnel avec profils de démonstration apprenant, formateur et administrateur.
- Ajout local de formations en mode administrateur.
- Téléchargement de supports texte provisoires.
- Interface responsive pour mobile et ordinateur.

## Lancer le site
Ouvrir `index.html` dans un navigateur. Pour le publier gratuitement avec GitHub Pages : dépôt GitHub → Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.

## Limites importantes
Ceci est une première version front-end, pas encore une plateforme de production. Les profils, inscriptions, formations ajoutées et progressions sont enregistrés dans le `localStorage` du navigateur et ne sont pas synchronisés entre utilisateurs ou appareils. Le choix du rôle sert uniquement à la démonstration et ne constitue pas un contrôle d'accès sécurisé.

Ne pas utiliser cette version pour collecter des données personnelles sensibles ou gérer de vrais apprenants. Les paiements, l'authentification sécurisée, la base de données partagée, les ressources réelles, les évaluations, les certificats vérifiables et les outils formateurs devront être ajoutés côté serveur.

## Architecture de production recommandée
1. Front-end responsive.
2. API et base de données partagée (PostgreSQL / Supabase ou équivalent).
3. Authentification et autorisations contrôlées côté serveur.
4. Gestion des rôles apprenant, formateur et administrateur.
5. Gestion des cours, leçons, fichiers, évaluations et inscriptions.
6. Progression centralisée et certificats avec vérification.
7. Politique de confidentialité, consentement parental pour les mineurs de 12 à 17 ans, sauvegardes et sécurité.

## Identité
OCOJE — « Une jeunesse haïtienne outillée et engagée ».
